# 05 — Ship

> Framework: Launch Checklist · Staged Rollout · Feature Flags  
> Goal: Get to users without breaking things and with maximum signal

---

## Environments

| Env | What it is | URL |
|---|---|---|
| **Development** | Local VS Code dev instance | `localhost` |
| **Staging** | Pre-release VSIX installable | `.vsix` file shared with testers |
| **Production** | VS Code Marketplace | `marketplace.visualstudio.com` |

For the website:
| Env | What it is | URL |
|---|---|---|
| **Development** | Local Next.js | `localhost:3000` |
| **Preview** | Vercel preview deploy | `reviewbrief-git-[branch].vercel.app` |
| **Production** | Live site | `reviewbrief.dev` |

---

## Versioning

Follow **Semantic Versioning (SemVer):** `MAJOR.MINOR.PATCH`

| Change type | Example | Version bump |
|---|---|---|
| Breaking change | Remove a feature users rely on | MAJOR (1.0.0 → 2.0.0) |
| New feature, backward compatible | Add note type labels | MINOR (1.0.0 → 1.1.0) |
| Bug fix | Fix selector extraction | PATCH (1.0.0 → 1.0.1) |

**V1 roadmap:**
- `0.1.0` — First internal build
- `0.5.0` — Staging / beta testers
- `1.0.0` — Marketplace launch
- `1.1.0` — Localhost URL support
- `1.2.0` — Chrome Extension launch

---

## Feature Flags

For a solo extension, feature flags are simple:  
VS Code `contributes.configuration` settings that toggle behavior.

```json
// package.json
"contributes": {
  "configuration": {
    "properties": {
      "reviewbrief.enableBetaFeatures": {
        "type": "boolean",
        "default": false,
        "description": "Enable experimental features"
      },
      "reviewbrief.enableViewportToggle": {
        "type": "boolean",
        "default": false,
        "description": "Show mobile/desktop viewport toggle (beta)"
      }
    }
  }
}
```

Users who want to test beta features opt in via settings.  
This lets you ship new features to willing testers before full release.

---

## Staged Rollout Plan

### Stage 0 — Private Alpha (Week 7)
**Who:** 3-5 people from Discovery conversations who said yes  
**How:** Share `.vsix` file directly (installable in VS Code via "Install from VSIX")  
**Goal:** Does the core loop work for real humans?  
**Feedback:** Async — DM, email, or voice note  
**Exit criteria:** No showstopper bugs reported

### Stage 1 — Public Beta (Week 8)
**Who:** Anyone who finds it  
**How:** GitHub release with `.vsix` download + README  
**Announce:** One Twitter thread: "I built this, here's what it does, download here"  
**Goal:** Catch edge cases, collect real usage patterns  
**Exit criteria:** 10+ installs, no critical bugs in 48 hours

### Stage 2 — Marketplace Launch (Week 9)
**Who:** VS Code Marketplace — full discoverability  
**How:** Submit for review, publish  
**Announce:** Full launch — Twitter, LinkedIn, Hacker News "Show HN", Product Hunt  
**Goal:** 100 installs in week 1  

### Stage 3 — Chrome Extension Beta (Week 12)
**How:** Chrome Web Store developer submission  
**Same staged approach:** private → GitHub release → store

---

## Pre-Launch Checklist

### Code
- [ ] All MVP acceptance criteria pass
- [ ] Regression checklist clean
- [ ] No `console.error` or unhandled promise rejections in happy path
- [ ] Extension activates cleanly on VS Code startup
- [ ] Tested on macOS (required) + Windows (best effort)
- [ ] Node version pinned in `.nvmrc`

### Repository
- [ ] Repo is public on GitHub
- [ ] README has: what it is, install instructions, GIF demo, license
- [ ] LICENSE file present (MIT)
- [ ] CHANGELOG.md exists with v1.0.0 entry
- [ ] Contributing guide exists (CONTRIBUTING.md)
- [ ] Issues templates configured (Bug Report, Feature Request)

### Marketplace Listing
- [ ] Extension icon (128x128 PNG)
- [ ] Description ≤ 200 characters (marketplace preview)
- [ ] Long description with screenshots
- [ ] Tags: `review`, `annotation`, `ai`, `productivity`, `notes`
- [ ] Categories: `Other`
- [ ] Publisher account verified

### Website (reviewbrief.dev)
- [ ] Homepage live with install CTA
- [ ] Docs: getting started guide
- [ ] Changelog page matches CHANGELOG.md
- [ ] Open Graph image for social sharing
- [ ] GitHub link prominent
- [ ] Noah Levin byline + about page

### Personal Brand
- [ ] Twitter thread written and scheduled
- [ ] LinkedIn post written
- [ ] Hacker News "Show HN" post drafted
- [ ] Product Hunt submission prepared (launch day)

---

## CHANGELOG.md Format

```markdown
# Changelog

All notable changes to ReviewBrief are documented here.

## [1.0.0] — 2025-MM-DD
### Added
- Local HTML file preview in VS Code panel
- Click-to-annotate on any element
- Note types: Bug, Design, Copy, Question
- Auto-save notes to `.review-notes/[date].md`
- Generate AI Brief — one-click structured fix instructions
- Copy brief to clipboard

## [0.5.0] — 2025-MM-DD
### Added
- Beta release for private testers
- Basic preview + annotation working
### Known Issues
- Localhost URL support not yet available
```

---

## Launch Day Runbook

Time-ordered actions for launch day:

```
08:00 — Confirm Marketplace listing is live
08:30 — Publish reviewbrief.dev
09:00 — Post Twitter thread
09:30 — Post LinkedIn
10:00 — Submit "Show HN" to Hacker News (best time: 9-11am US Eastern)
12:00 — Launch on Product Hunt (midnight PT the night before)
All day — Respond to every comment and reply
EOD — Note install count, top questions, first bug reports
```
