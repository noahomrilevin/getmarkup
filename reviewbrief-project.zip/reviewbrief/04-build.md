# 04 — Build

> Framework: Agile / Sprint Planning · Sprint Brief · TDD · Ship/Don't Ship Criteria  
> Goal: Structure the build so progress is visible and quality is checkable

---

## Sprint Structure

**Sprint length:** 1 week (solo dev, one hand, AI-assisted — shorter is better)  
**Sprint ceremony (solo version):**
- Monday: Write Sprint Brief (30 min)
- Daily: One Whisper Flow session narrating what you're working on
- Friday: Review what shipped vs. didn't, update backlog

**Tool:** Everything lives in these MD files + GitHub Issues

---

## Sprint Brief Template

> This is the source of truth for every sprint. Fill it out before touching code.

```markdown
# Sprint Brief — Week [N]
**Dates:** [start] → [end]  
**Sprint Goal:** [One sentence. What does done look like?]

## This Sprint
| Story | Points | Acceptance Criteria | Done? |
|---|---|---|---|
| [story] | [n] | [what makes it done] | [ ] |

## Dependencies / Blockers
- [anything that could stop this sprint]

## What We're NOT Doing This Sprint
- [explicit out of scope for the week]

## Definition of Done
- [ ] Feature works as described in acceptance criteria
- [ ] No regressions in existing features
- [ ] Code committed to GitHub
- [ ] CHANGELOG.md updated
```

---

## Sprint Plan — VS Code Extension MVP

### Sprint 1 — Scaffold (Week 1)
**Goal:** VS Code extension boots, panel opens, shows a blank webview

| Story | Points | Acceptance Criteria |
|---|---|---|
| Scaffold extension with `yo code` | 2 | Extension installs in VS Code, shows in sidebar |
| Webview panel opens on command | 3 | "Open ReviewBrief" command creates panel |
| Basic HTML renders in webview | 3 | A test HTML string displays in the panel |
| Project structure and GitHub repo set up | 1 | Repo public, README with setup instructions |

**Ship / Don't Ship:** Ship if panel opens and renders content. Don't ship if webview is blank.

---

### Sprint 2 — Preview (Week 2)
**Goal:** Local HTML file renders in the preview panel

| Story | Points | Acceptance Criteria |
|---|---|---|
| File picker lets user select .html file | 3 | User can browse and select a local .html file |
| Selected file renders in webview | 5 | File content displays, CSS and relative assets load |
| Localhost URL input renders in webview | 3 | User types `localhost:3000`, it renders |
| Error state for invalid path/URL | 2 | Friendly error message shown, not a crash |

**Ship / Don't Ship:** Ship if real HTML renders. Don't ship if only hardcoded content works.

---

### Sprint 3 — Annotate (Week 3)
**Goal:** User can click any element and leave a note

| Story | Points | Acceptance Criteria |
|---|---|---|
| Click overlay injects into preview | 5 | Clicking any element highlights it |
| Note input form appears on click | 3 | Form shows selector + text area |
| Note type selector (Bug/Design/Copy/?) | 2 | User can pick type before saving |
| Note saves to in-memory state | 3 | Saved note appears in sidebar list |

**Ship / Don't Ship:** Ship if note appears in sidebar after clicking. Don't ship if selector is wrong or form doesn't appear.

---

### Sprint 4 — Persist (Week 4)
**Goal:** Notes survive VS Code restarts

| Story | Points | Acceptance Criteria |
|---|---|---|
| Notes write to `.review-notes/[date].md` | 5 | MD file appears in project folder on save |
| Notes load from MD file on panel open | 5 | Existing notes appear after reopening VS Code |
| MD file is human-readable | 2 | Format is clean markdown, no JSON bleed |

**Ship / Don't Ship:** Ship if notes exist in the file system and reload correctly. Don't ship if notes are lost on restart.

---

### Sprint 5 — AI Brief (Week 5)
**Goal:** One-click AI Brief generation

| Story | Points | Acceptance Criteria |
|---|---|---|
| "Generate AI Brief" button in session bar | 2 | Button exists and is clickable |
| Brief compiles all notes into format | 5 | Output matches the format spec in 02-define.md exactly |
| Brief displays in panel | 3 | Brief appears in readable panel within the tool |
| Copy to clipboard in one click | 2 | Clipboard contains the brief text after click |

**Ship / Don't Ship:** Ship if brief copies correctly. Don't ship if format doesn't match spec or copy fails.

---

### Sprint 6 — Polish + Launch Prep (Week 6)
**Goal:** MVP is solid enough to publish to VS Code Marketplace

| Story | Points | Acceptance Criteria |
|---|---|---|
| Error handling for all failure modes | 3 | No unhandled crashes in normal use |
| README with GIF demo | 3 | README explains install + use in under 2 min read |
| Package.json metadata complete | 1 | Name, description, icon, categories correct |
| Extension icon designed | 2 | 128x128 icon, matches brand |
| Marketplace listing draft | 2 | Description, screenshots, tags ready |

---

## TDD — Test-Driven Development (Lightweight Solo Version)

> Full TDD is write-test-before-code. Solo with AI, we adapt:  
> Write acceptance criteria first. Ask Claude to write tests against them. Then build.

### Test Strategy

| Layer | What to test | Tool |
|---|---|---|
| Unit | Note formatting, selector extraction, brief generation | Jest |
| Integration | File read/write, webview message passing | VS Code Extension Testing |
| E2E | Full flow: open file → annotate → generate brief | Manual + Playwright |

### Example: Brief Generator Unit Test

```typescript
// test/briefGenerator.test.ts
describe('generateBrief', () => {
  it('formats a bug note correctly', () => {
    const note = {
      type: 'bug',
      selector: '.hero h1',
      text: 'Font too large on mobile'
    };
    const brief = generateBrief([note]);
    expect(brief).toContain('🐛 Bug');
    expect(brief).toContain('.hero h1');
    expect(brief).toContain('Font too large on mobile');
  });

  it('handles empty notes array', () => {
    expect(generateBrief([])).toContain('No issues recorded');
  });
});
```

**Workflow with Claude:**
1. Write acceptance criteria (already done in 02-define.md)
2. Say to Claude: "Write Jest tests that validate these acceptance criteria"
3. Claude writes tests — they all fail (red)
4. Say: "Now write the implementation to pass these tests"
5. Tests pass (green)
6. Commit

---

## Tech Debt Tracker

> Log tech debt honestly. Don't pretend it doesn't exist.

```markdown
## Known Tech Debt — V1

| Item | Where | Priority | Notes |
|---|---|---|---|
| Iframe security model is basic | PreviewPanel | High | Need CSP headers for prod |
| No error boundary on webview crash | Extension host | Medium | Add for V1.1 |
| MD parsing is manual string ops | noteStorage.ts | Low | Replace with gray-matter in V2 |
```

---

## Regression Checklist

Run this before every release:

- [ ] Open a local .html file → renders correctly
- [ ] Click an element → note form appears with correct selector
- [ ] Save a note → appears in sidebar
- [ ] Close and reopen VS Code → notes still appear
- [ ] Generate AI Brief → matches format spec
- [ ] Copy brief → clipboard contains correct text
- [ ] Test on Mac, Windows (or document Windows limitation)

---

## Ship / Don't Ship Criteria — Global

**Ship when:**
- All MVP acceptance criteria pass
- Regression checklist is clean
- README explains install and use clearly
- No known crashes in happy path
- CHANGELOG.md has entry for this version

**Don't ship when:**
- Any regression is introduced
- Core flow (open → annotate → brief) is broken
- Notes are lost or corrupted
- Extension crashes on install
