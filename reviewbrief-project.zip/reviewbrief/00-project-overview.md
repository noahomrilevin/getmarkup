# ReviewBrief — Master Project Overview

> An open-source local HTML/webapp review tool with AI fix-brief output.  
> Built in public by **Noah Levin** — CPO, builder, rabbi-in-training.

---

## What We're Building

| Product | Format | Status |
|---|---|---|
| **ReviewBrief** | VS Code Extension | Primary build |
| **ReviewBrief Web** | Chrome Extension | Secondary build |
| **reviewbrief.dev** | Marketing + Docs Site | Launch vehicle |

### The Core Loop
```
Open local file or localhost URL
  → Preview renders in panel
    → Click any element → attach a note
      → Notes auto-save as .md files
        → "Generate AI Brief" outputs structured fix instructions
          → Paste directly into Claude / Cursor / Copilot
```

### The Differentiator
Nobody outputs notes in a format optimized for AI ingestion.  
That's the product. Everything else is scaffolding around that moment.

---

## Personal Brand Angle

This project is built in public, narrated by Noah Levin.  
Every phase — research, design decisions, code — gets documented and shared.

**Channels:**
- GitHub (open source, public commits)
- Twitter/X build log threads
- LinkedIn longer-form reflections
- reviewbrief.dev/blog (personal voice, not corporate)

**Positioning:** "I'm a one-handed CPO building the tool I wish existed.  
Here's everything I learn."

That story is more powerful than any feature list.

---

## Phase Map

| # | Phase | Focus | Deliverable |
|---|---|---|---|
| 1 | Discovery | Is this a real gap? | Research Report |
| 2 | Define | What exactly are we building? | PRD + User Stories |
| 3 | Design | How does it look and feel? | Component System |
| 4 | Build | Make it real | Shipped MVP |
| 5 | Ship | Get it to users | Launch |
| 6 | Learn | Did it work? | Retrospective + V2 Backlog |

---

## North Star Metric

**Weekly Active Annotators** — users who open the tool and attach at least one note per week.

This measures actual workflow adoption, not installs.

---

## Files in This Project

```
/reviewbrief
  00-project-overview.md   ← you are here
  01-discovery.md          ← research study + competitive analysis
  02-define.md             ← JTBD, user stories, MoSCoW, PRD
  03-design.md             ← design sprint, component system, accessibility
  04-build.md              ← sprint plan, TDD, acceptance criteria
  05-ship.md               ← launch checklist, staged rollout, feature flags
  06-learn.md              ← HEART metrics, OKRs, retrospective template
```
