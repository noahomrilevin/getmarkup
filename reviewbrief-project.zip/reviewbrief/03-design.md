# 03 — Design

> Framework: Design Sprint (GV) · Atomic Design System · Accessibility WCAG  
> Goal: Define the look, feel, and component architecture before writing UI code

---

## Design Sprint — Compressed (Solo Version)

> Google Ventures Design Sprint is 5 days with a team.  
> Solo with AI, we compress it to a structured sequence of decisions.

### Day 1 — Understand (Map the problem)
**Output:** A flow diagram of the core user journey

```
User opens VS Code
  → Opens ReviewBrief panel (sidebar or split view)
    → Selects file path or types localhost URL
      → Preview renders
        → User scrolls, finds issue
          → Clicks element
            → Note input appears (overlay or sidebar form)
              → Types note, selects type (Bug/Design/Copy/Question)
                → Note saves automatically
                  → Pin appears on preview at click position
                    → Repeat for all issues
                      → Clicks "Generate AI Brief"
                        → Brief appears in panel
                          → One-click copy to clipboard
                            → Pastes into Claude → fixes happen
```

### Day 2 — Sketch (Crazy 8s)
**Output:** 8 rough layout ideas for the main panel

For a solo AI-assisted build, this becomes:
- Prompt Claude with the flow above
- Ask for 8 different layout approaches described in words
- Pick the one that feels right for one-handed use
- Describe it back to Claude as a wireframe prompt

**Layout chosen:** Two-panel split
- Left: Preview (resizable)
- Right: Notes sidebar (scrollable list + form at bottom)
- Bottom bar: Session info + "Generate Brief" button

### Day 3 — Decide
**Output:** Final wireframe description (source of truth for implementation)

```
┌─────────────────────────────┬──────────────────────────┐
│                             │  NOTES                   │
│   PREVIEW PANEL             │  ─────────────────────── │
│                             │  🐛 .hero h1              │
│   [renders local HTML]      │  Font too large mobile    │
│                             │                           │
│   [clickable overlay]       │  🎨 nav .logo             │
│                             │  Pixelated on retina      │
│                             │  ─────────────────────── │
│                             │  + New note input         │
│                             │  [type here...]           │
│                             │  [Bug][Design][Copy][?]   │
│                             │  [Save Note]              │
├─────────────────────────────┴──────────────────────────┤
│  Session: index.html · 2 notes · [Generate AI Brief]   │
└────────────────────────────────────────────────────────┘
```

### Day 4 — Prototype
Build the UI in HTML first (ironic given the product).
Use this as the Webview content in VS Code extension.

### Day 5 — Validate
Share the prototype with 3 people from Discovery.
Ask: "Does this feel like it fits your workflow?"

---

## Atomic Design System

> Build components from atoms up so everything stays consistent.

### Design Tokens (Variables)

```css
:root {
  /* Color */
  --color-bg: #1e1e1e;          /* VS Code dark default */
  --color-surface: #252526;
  --color-border: #3e3e42;
  --color-text: #cccccc;
  --color-text-muted: #858585;
  --color-accent: #0e7fd4;      /* VS Code blue */
  
  /* Note type colors */
  --color-bug: #f48771;         /* red-ish */
  --color-design: #9cdcfe;      /* blue-ish */
  --color-copy: #ce9178;        /* orange-ish */
  --color-question: #dcdcaa;    /* yellow-ish */

  /* Spacing */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;

  /* Typography */
  --font-ui: -apple-system, 'Segoe UI', sans-serif;
  --font-mono: 'Cascadia Code', 'Fira Code', monospace;
  --size-sm: 11px;
  --size-base: 13px;
  --size-lg: 15px;
}
```

### Atoms (smallest units)

| Component | Description |
|---|---|
| `<NoteTypeTag>` | Colored pill: Bug / Design / Copy / Question |
| `<SelectorChip>` | Monospace CSS selector display |
| `<IconButton>` | Icon-only button (copy, delete, collapse) |
| `<StatusDot>` | Saved / unsaved indicator |

### Molecules (atoms combined)

| Component | Made of |
|---|---|
| `<NoteCard>` | NoteTypeTag + SelectorChip + text + IconButton(s) |
| `<NoteForm>` | Text input + NoteTypeTag selector + Save button |
| `<SessionBar>` | File name + note count + Generate Brief button |

### Organisms (full sections)

| Component | Made of |
|---|---|
| `<NotesSidebar>` | List of NoteCards + NoteForm at bottom |
| `<PreviewPanel>` | Iframe/webview + clickable overlay |
| `<BriefOutput>` | Generated markdown + Copy button |

### Templates

| Template | Description |
|---|---|
| `ReviewPanel` | Two-column layout: Preview + Sidebar |
| `BriefModal` | Overlay with generated brief + copy action |

---

## Accessibility — WCAG 2.1 AA

The tool must be fully usable with one hand and keyboard only.  
This isn't just an accessibility goal — it's a personal requirement.

### Keyboard Navigation Requirements
- [ ] All interactive elements reachable by Tab
- [ ] Note form submittable with Enter
- [ ] Type selector navigable with arrow keys
- [ ] Copy brief triggerable with keyboard shortcut (Cmd/Ctrl+Shift+C)
- [ ] Preview panel scrollable with keyboard

### Visual Requirements
- [ ] Color is never the only indicator (icons + labels alongside color)
- [ ] Minimum contrast 4.5:1 for all text
- [ ] Focus rings visible on all interactive elements
- [ ] Note type icons have aria-labels

### Motion
- [ ] No animations that can't be disabled
- [ ] Respects `prefers-reduced-motion`

### Screen Reader
- [ ] Note cards have descriptive aria-labels
- [ ] Generate Brief button announces result
- [ ] Error states announced to screen reader

---

## Chrome Extension Design Notes

The Chrome extension follows the same design system but adapts to browser context:

- Sidebar injected into the page (not a popup) — more real estate
- Preview is the actual tab — no iframe needed
- Same NoteCard and NoteForm components
- Brief output opens in a new panel or copies directly
- All tokens identical — feels like same product in different shell

---

## Website — reviewbrief.dev

### Pages
1. **Homepage** — Hero (product demo GIF), value prop, install buttons
2. **Docs** — Getting started, note format spec, AI brief format
3. **Changelog** — Every version, honest about what changed
4. **/blog** — Noah's build-in-public posts, product decisions, learnings

### Design Direction
- Dark, minimal — matches the VS Code tool aesthetic
- No stock photos — only real product screenshots
- Personal byline on every page: "Built by Noah Levin"
- Open source badge + GitHub star count prominent in nav

### Stack
- Next.js (matches vibe coding target audience)
- Tailwind
- Deployed on Vercel
- Docs in MDX
