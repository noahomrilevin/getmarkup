# ReviewBrief

> Annotate local HTML previews. Generate structured AI fix briefs. Ship faster.

**Status:** Pre-launch — building in public  
**Built by:** [Noah Levin](https://noahlevin.com)

---

## What it does

ReviewBrief is a VS Code extension that gives solo developers a lightweight review workflow:

1. Open any local HTML file or localhost URL in the preview panel
2. Click any element to attach a note (Bug, Design, Copy, or Question)
3. Notes auto-save to `.review-notes/` in your project as markdown files
4. Click **Generate AI Brief** — get structured fix instructions ready to paste into Claude, Cursor, or Copilot

---

## Install

Coming to VS Code Marketplace. Until then:

```bash
# Download the .vsix from GitHub Releases
# In VS Code: Cmd+Shift+P → Extensions: Install from VSIX
```

---

## Why

When you're building alone with AI, the gap between "I see something wrong" and "the AI fixes it correctly" is a prompting problem. ReviewBrief closes that gap by structuring your observations into a format AI tools actually understand.

---

## Open Source

MIT License. Contributions welcome.  
See [CONTRIBUTING.md](./CONTRIBUTING.md) for how to get involved.

---

## Built in Public

Follow the build at [@noahlevin](https://twitter.com/noahlevin).  
Every sprint, every decision, every lesson — documented publicly.
