# Changelog

All notable changes to ReviewBrief are documented here.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).  
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### In Progress
- VS Code extension scaffold (Sprint 1)

---

## [0.1.0] — TBD
### Added
- Initial project setup
- Project plan and discovery documents
