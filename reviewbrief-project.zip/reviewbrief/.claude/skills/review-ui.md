# Skill — ReviewBrief UI: Design Tokens + Components

> Paste this when working on any webview HTML/CSS/JS.  
> All UI must use these tokens. No hardcoded colors or sizes.

---

## Design Tokens (CSS Variables)

```css
:root {
  /* Background layers */
  --color-bg: #1e1e1e;
  --color-surface: #252526;
  --color-surface-raised: #2d2d30;
  --color-border: #3e3e42;

  /* Text */
  --color-text: #cccccc;
  --color-text-muted: #858585;
  --color-text-bright: #ffffff;

  /* Accent */
  --color-accent: #0e7fd4;
  --color-accent-hover: #1184da;

  /* Note type colors */
  --color-bug: #f48771;
  --color-design: #9cdcfe;
  --color-copy: #ce9178;
  --color-question: #dcdcaa;

  /* Status */
  --color-success: #4ec9b0;
  --color-warning: #cca700;
  --color-error: #f48771;

  /* Spacing scale */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 16px;
  --space-lg: 24px;
  --space-xl: 40px;

  /* Typography */
  --font-ui: -apple-system, 'Segoe UI', 'Ubuntu', sans-serif;
  --font-mono: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  --size-xs: 10px;
  --size-sm: 11px;
  --size-base: 13px;
  --size-lg: 15px;

  /* Borders */
  --radius-sm: 3px;
  --radius-md: 6px;
  --border: 1px solid var(--color-border);
}
```

---

## Layout (Two-Panel Split)

```html
<div class="reviewbrief-shell">
  <div class="preview-panel">
    <!-- iframe or webview content here -->
  </div>
  <div class="notes-sidebar">
    <div class="notes-list">
      <!-- NoteCards rendered here -->
    </div>
    <div class="note-form-area">
      <!-- NoteForm always visible at bottom -->
    </div>
  </div>
  <div class="session-bar">
    <!-- file name, note count, generate button -->
  </div>
</div>
```

```css
.reviewbrief-shell {
  display: grid;
  grid-template-columns: 1fr 320px;
  grid-template-rows: 1fr 48px;
  height: 100vh;
  background: var(--color-bg);
  color: var(--color-text);
  font-family: var(--font-ui);
  font-size: var(--size-base);
}

.preview-panel {
  grid-row: 1;
  grid-column: 1;
  overflow: hidden;
  border-right: var(--border);
}

.notes-sidebar {
  grid-row: 1;
  grid-column: 2;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.notes-list {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-sm);
}

.note-form-area {
  border-top: var(--border);
  padding: var(--space-sm);
  background: var(--color-surface);
}

.session-bar {
  grid-row: 2;
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-md);
  border-top: var(--border);
  background: var(--color-surface);
}
```

---

## Components

### NoteTypeTag

```html
<span class="note-type-tag note-type-tag--bug">🐛 Bug</span>
<span class="note-type-tag note-type-tag--design">🎨 Design</span>
<span class="note-type-tag note-type-tag--copy">✍️ Copy</span>
<span class="note-type-tag note-type-tag--question">❓ Question</span>
```

```css
.note-type-tag {
  display: inline-flex;
  align-items: center;
  gap: var(--space-xs);
  padding: 2px var(--space-sm);
  border-radius: var(--radius-sm);
  font-size: var(--size-sm);
  font-weight: 500;
}
.note-type-tag--bug      { background: rgba(244,135,113,0.15); color: var(--color-bug); }
.note-type-tag--design   { background: rgba(156,220,254,0.15); color: var(--color-design); }
.note-type-tag--copy     { background: rgba(206,145,120,0.15); color: var(--color-copy); }
.note-type-tag--question { background: rgba(220,220,170,0.15); color: var(--color-question); }
```

---

### SelectorChip

```html
<code class="selector-chip">.hero .cta-button</code>
```

```css
.selector-chip {
  font-family: var(--font-mono);
  font-size: var(--size-sm);
  color: var(--color-text-muted);
  background: var(--color-surface-raised);
  padding: 1px var(--space-xs);
  border-radius: var(--radius-sm);
  border: var(--border);
}
```

---

### NoteCard

```html
<div class="note-card" data-id="[id]">
  <div class="note-card__header">
    <span class="note-type-tag note-type-tag--bug">🐛 Bug</span>
    <button class="icon-btn" aria-label="Delete note">✕</button>
  </div>
  <code class="selector-chip">.hero .cta-button</code>
  <p class="note-card__text">Font too large on mobile</p>
</div>
```

```css
.note-card {
  background: var(--color-surface);
  border: var(--border);
  border-radius: var(--radius-md);
  padding: var(--space-sm);
  margin-bottom: var(--space-sm);
  display: flex;
  flex-direction: column;
  gap: var(--space-xs);
}
.note-card__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.note-card__text {
  font-size: var(--size-base);
  color: var(--color-text);
  margin: 0;
  line-height: 1.5;
}
```

---

### NoteForm

```html
<div class="note-form">
  <div class="note-form__selector">
    <code class="selector-chip">Click an element to select it</code>
  </div>
  <div class="note-form__types">
    <button class="type-btn type-btn--active" data-type="bug">🐛 Bug</button>
    <button class="type-btn" data-type="design">🎨 Design</button>
    <button class="type-btn" data-type="copy">✍️ Copy</button>
    <button class="type-btn" data-type="question">❓</button>
  </div>
  <textarea class="note-form__input" placeholder="Describe the issue..." rows="3"></textarea>
  <button class="btn-primary" id="save-note">Save Note</button>
</div>
```

```css
.note-form { display: flex; flex-direction: column; gap: var(--space-sm); }
.note-form__types { display: flex; gap: var(--space-xs); flex-wrap: wrap; }

.type-btn {
  padding: 3px var(--space-sm);
  border: var(--border);
  border-radius: var(--radius-sm);
  background: transparent;
  color: var(--color-text-muted);
  font-size: var(--size-sm);
  cursor: pointer;
}
.type-btn--active { background: var(--color-accent); color: white; border-color: var(--color-accent); }

.note-form__input {
  width: 100%;
  background: var(--color-surface-raised);
  border: var(--border);
  border-radius: var(--radius-sm);
  color: var(--color-text);
  font-family: var(--font-ui);
  font-size: var(--size-base);
  padding: var(--space-sm);
  resize: vertical;
  box-sizing: border-box;
}
.note-form__input:focus { outline: none; border-color: var(--color-accent); }

.btn-primary {
  background: var(--color-accent);
  color: white;
  border: none;
  border-radius: var(--radius-sm);
  padding: var(--space-sm) var(--space-md);
  font-size: var(--size-base);
  cursor: pointer;
  width: 100%;
}
.btn-primary:hover { background: var(--color-accent-hover); }
```

---

### Session Bar

```html
<div class="session-bar">
  <span class="session-info">
    <span class="session-filename">index.html</span>
    <span class="session-count">3 notes</span>
  </span>
  <button class="btn-generate" id="generate-brief">Generate AI Brief</button>
</div>
```

```css
.session-filename { color: var(--color-text-bright); font-weight: 500; margin-right: var(--space-sm); }
.session-count    { color: var(--color-text-muted); font-size: var(--size-sm); }

.btn-generate {
  background: var(--color-success);
  color: #000;
  border: none;
  border-radius: var(--radius-sm);
  padding: var(--space-xs) var(--space-md);
  font-size: var(--size-sm);
  font-weight: 600;
  cursor: pointer;
}
```

---

## Accessibility Requirements

Every interactive element must have:
- `aria-label` if no visible text
- Visible focus ring: `outline: 2px solid var(--color-accent); outline-offset: 2px;`
- Keyboard operability (Tab + Enter/Space)
- `prefers-reduced-motion` respected for any transitions
