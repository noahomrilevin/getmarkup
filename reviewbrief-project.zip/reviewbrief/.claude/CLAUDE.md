# CLAUDE.md — ReviewBrief Project Context

> Paste this at the start of EVERY Claude session.  
> Update the Current Sprint section each week.

---

## What This Project Is

ReviewBrief is a VS Code extension that lets developers annotate local HTML previews and generate structured AI fix briefs. The brief is structured markdown, ready to paste directly into Claude, Cursor, or Copilot.

**Three products being built:**
1. VS Code Extension — primary, build first
2. Chrome Extension — Phase 2
3. reviewbrief.dev — marketing site, build alongside extension

**Open source. Built in public by Noah Levin.**

---

## Current Sprint

> UPDATE THIS EVERY SPRINT — this is the most important line

**Phase:** Build  
**Sprint:** 1  
**Sprint Goal:** VS Code extension boots, panel opens, shows blank webview  
**Sprint file:** docs/04-build.md → Sprint 1  

---

## Stack

- **Language:** TypeScript
- **Platform:** VS Code Extension API
- **UI:** Webview panel (HTML/CSS/JS inside VS Code)
- **Storage:** Local file system — `.review-notes/[date].md`
- **No backend. No cloud. No login. No telemetry (unless opted in).**

---

## Key Files Claude Must Know

| File | What it contains |
|---|---|
| `docs/02-define.md` | Acceptance criteria, user stories, AI brief format spec |
| `docs/04-build.md` | Current sprint, story points, done criteria |
| `docs/03-design.md` | Design tokens, component names, layout spec |
| `CHANGELOG.md` | Version history — update before every release |

---

## Rules Claude Must Always Follow

- **Never** suggest adding cloud sync, a backend, or login
- **Never** add telemetry without explicit user request
- **Always** check acceptance criteria in `docs/02-define.md` before saying something is done
- **Always** write TypeScript with explicit types — no `any`
- **Keep it simple** — this is a solo project, not enterprise software
- **When in doubt, do less and do it well**
- **One file per concern** — don't dump everything in extension.ts

---

## The Core User Journey

```
User opens VS Code
  → Opens ReviewBrief panel
    → Selects local .html file or localhost URL
      → Preview renders
        → Clicks any element → note input appears
          → Types note, picks type (Bug/Design/Copy/Question)
            → Note saves automatically to .review-notes/[date].md
              → Repeat for all issues
                → Clicks "Generate AI Brief"
                  → Brief appears → one-click copy
                    → Pastes into Claude → fixes happen
```

---

## AI Brief Output Format (non-negotiable)

The brief generator must produce exactly this format:

```markdown
# ReviewBrief — Fix Instructions
**Project:** [filename]
**Reviewed:** [date] at [time]
**Total Issues:** [n]

---

## 🐛 Bug — High Priority
**Element:** [human readable name]
**Selector:** [css selector]
**Issue:** [what's wrong]
**Expected:** [what should happen]

---

## 🎨 Design
**Element:** [name]
**Selector:** [selector]
**Issue:** [description]
**Expected:** [description]
```

Full spec in `docs/02-define.md` → AI Brief Output Format section.

---

## Current Acceptance Criteria — MVP

The MVP is done when ALL of these pass:

- [ ] User can open a local .html file and see it render in VS Code panel
- [ ] Clicking an element opens a note input pre-filled with its selector
- [ ] Notes save automatically — no manual save step
- [ ] Closing and reopening VS Code shows existing notes
- [ ] "Generate AI Brief" produces the exact format above
- [ ] Brief copies to clipboard on one click
- [ ] Notes are stored as readable .md files in the project folder
- [ ] Tool works without internet connection
- [ ] No login, no account, no telemetry without opt-in

---

## Workflow Context

- Developer: Noah Levin (one-handed, voice-first via Whisper Flow)
- All commands run via VS Code Tasks, not terminal typing
- Multiple Claude tabs open in parallel (builder / checker / debugger)
- Commits happen via `Git: Commit All` task

---

## What's Explicitly Out of Scope (never suggest these)

- Real-time collaboration
- Cloud sync or remote storage
- Jira / Linear / GitHub Issues integration
- Auto-fix (we output the brief, not the fix)
- Support for non-web projects
- AI that reads the preview and generates notes automatically (V3 maybe, not now)
